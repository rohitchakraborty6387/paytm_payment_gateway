# payment-using-paytm-php
PayTM Payment Gateway Integration in Core PHP.
Payment Gateway Integration in the Website in Core PHP.  
