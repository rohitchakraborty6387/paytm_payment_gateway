-- Database: `webscodex`
-- --------------------------------------------------------
-- Table structure for table `payment_txn`
--

CREATE TABLE `payment_txn` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` varchar(100) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `status` varchar(100) NOT NULL,
  `txns_id` varchar(100) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `txns_date` datetime NOT NULL,
  `gateway_name` varchar(100) NOT NULL,
  `bank_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
