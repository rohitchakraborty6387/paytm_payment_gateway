<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Paytm Payment Gateway Integration in PHP Step by Step</title>
        <!-- Bootstrap CSS -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    </head>
    <body>
    <div class="container">
        <div class="py-5 text-center">
            <h2> Paytm Payment Gateway Integration Checkout Form</h2>
            <p class="lead">This Checkout page using Paytm Payment Gateway for Testing purpose </p>
        </div>
        <form action="http://localhost/Paytm-payment-gateway-in-php/PaytmKit/pgRedirect.php" method="POST">
            <div class="row">
                <div class="col-md-8 order-md-1">
                    <h4 class="mb-3">Billing address</h4>
                    <div class="card p-3">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label for="firstName">Full Name </label>
                                <input type="text" class="form-control" name="full_name" placeholder="Full Name" required="">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="mobile">Mobile Number</label>
                            <div class="input-group">                              
                                <input type="text" class="form-control" name="mobile_number" placeholder="Mobile Number" required="">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="email">Email <span class="text-muted">(Optional)</span></label>
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <div class="mb-3">
                            <label for="address">Flat, House no. Area, Street, Sector, Village</label>
                            <input type="text" class="form-control" name="address" required="">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="city">Town/City</label>
                                <input type="text" class="form-control" placeholder="Town/City">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="pincode">Pincode</label>
                                <input type="text" class="form-control" name="pincode" placeholder="6 digits [0-9] Pin code" required="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 order-md-2 mb-4">
                    <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span>Your cart</span>
                        <span class="badge badge-secondary badge-pill">3</span>
                    </h4>
                    <ul class="list-group mb-3 sticky-top">
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">First Product</h6>
                                <small class="text-muted">Brief description</small>
                            </div>
                            <span class="text-muted">₹12,000</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">Second Product</h6>
                                <small class="text-muted">Brief description</small>
                            </div>
                            <span class="text-muted">₹8,000</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">Third Product</h6>
                                <small class="text-muted">Brief description</small>
                            </div>
                            <span class="text-muted">₹5,000</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span><strong> Order Total: </strong></span>
                            <input type="hidden" name="order_amount" value="25000" />
                            <strong>₹25,000</strong>
                        </li>
                    </ul>
                    <div class="card p-2">
                        <button class="btn btn-primary btn-block" type="submit" name="check_out">Continue to checkout</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>
